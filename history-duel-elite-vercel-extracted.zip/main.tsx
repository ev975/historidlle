
import React, { useEffect, useState } from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import { supabase } from './lib/supabase'

function App(){
  const [user,setUser]=useState<any>(null)
  useEffect(()=>{ (async()=>{ const { data:{ user } } = await supabase!.auth.getUser(); setUser(user) })() },[])
  async function signIn(){ const email = prompt('Email for magic link')||''; const { error } = await supabase!.auth.signInWithOtp({ email }); if (error) alert(error.message); else alert('Check email') }
  async function signOut(){ await supabase!.auth.signOut(); setUser(null) }
  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-3">History Duel</h1>
      <div className="flex gap-2 mb-6">
        {!user ? <button className="border rounded-xl px-4 py-2" onClick={signIn}>Sign in</button> : <button className="border rounded-xl px-4 py-2" onClick={signOut}>Sign out</button>}
        <a className="border rounded-xl px-4 py-2" href="/online">Realtime</a>
        <a className="border rounded-xl px-4 py-2" href="/online/queue">Matchmaking</a>
        <a className="border rounded-xl px-4 py-2" href="/leaderboard">Leaderboard</a>
      </div>
      <p className="text-sm opacity-80">This build is pre-wired for Vercel. Set env vars and deploy.</p>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />)
