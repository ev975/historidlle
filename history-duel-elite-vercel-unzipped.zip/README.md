
# History Duel — Vercel Ready

Deploy steps (under 2 minutes):
1) Create a new GitHub repo and push these files.
2) Go to https://vercel.com/new and import the repo.
3) Set Environment Variables in Vercel:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4) Framework preset: **Vite** (build: `npm run build`, output: `dist`)
5) Deploy. Share your link: `https://<project>.vercel.app`

SPA routing and PWA manifest are handled by `vercel.json`.
